#include <iostream>

using namespace std;

void func1()
{
    cout << "Hello, Youtube!" << endl;
}