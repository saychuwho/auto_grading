#include <iostream>

using namespace std;

void func2(int a, int b)
{
    cout << a+b << endl;
}