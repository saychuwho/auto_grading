#include <iostream>
#include <string>

using namespace std;

string func3(string a, string b)
{
    return a+b;
}