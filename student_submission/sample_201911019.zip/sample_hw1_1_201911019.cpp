#include <iostream>


void func1()
{
    cout << "Hello, World!" << endl;
}