#include <iostream>

using namespace std;

int func2(int a, int b)
{
    return a+b;
}